$('input[name="phone"].sample').on('input blur focus', function(e) {
	var el = e.target, pattern = $(el).attr('placeholder'),
	matrix = pattern.replace(/[\d+]/g, "_"),
	i = 0,
	val = $(el).val().replace(/[^\d+]/g, "");
	$(el).val(matrix.replace(/./g, function (a) {
		return /[_\d]/.test(a) && i < val.length ? val.charAt(i++) : i >= val.length ? "" : a;
	}));
}).trigger('input');

$('input[name="phone"].mask').on('input blur focus', function(e) {
	var el = e.target, val = $(el).val();
	if(!val) return;
	if(val.substr(0, 1) !== '+') {
		$(el).val('+'+val);
	}
});


$('input[name="phone"].mask').each(function(e) {
    var $input = $(this);

	$(this).intlTelInput({
		utilsScript: 'https://cdn.iplogger.org/js/utils.js',
		nationalMode: false,
		separateDialCode: false,
		preferredCountries: ['us', 'gb', 'in', 'br', 'es', 'pt'],
		customPlaceholder: function(phone, country) {
        	phone = phone.replace(/[^+0-9]+/g, '');
            $input.parent().attr('data-placeholder', phone);
        	return '';
		}
	});
});
