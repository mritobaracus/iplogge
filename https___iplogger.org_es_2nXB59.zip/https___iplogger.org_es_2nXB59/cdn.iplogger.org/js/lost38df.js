function lost(json) {	console.log('lost', json);
    if(json.complete != 1) {    	return;
    }
    $('.block-form-inner[data-stage]').attr('data-stage', 2);
}
