function pikulinTrigger(element,event) {
    if ("createEvent" in document) {
        let evt = document.createEvent("HTMLEvents");
        evt.initEvent(event, false, true);
        element.dispatchEvent(evt);
    }
    else
        element.fireEvent("on"+event);
}

var bt;

function initCustomSelect() {
    document.querySelectorAll('.for-custom-select:not(.custom-select-inited)').forEach(container=>{
        container.classList.add('custom-select-inited');
        const custom_select = container.querySelector('.custom-select'),
            fields = container.querySelectorAll('.input input, .field'),
            main_field = document.querySelector(custom_select.getAttribute('data-toggle')),
            btn_prev = container.querySelector('.btn-custom-select-prev'),
            btn_next = container.querySelector('.btn-custom-select-next'),
            index = container.querySelector('.custom-select-index'),
            buttons = custom_select.querySelectorAll('button'),
            buttons_count = buttons.length;
        let showed = false;
        let max_height = 0;
        let change_field = true;
        if(custom_select.hasAttribute('data-max-lines')) {
            max_height = custom_select.querySelector('button').getBoundingClientRect().height*parseInt(custom_select.getAttribute('data-max-lines'));
        }
        let i = 0;
        buttons.forEach(btn=>{
            i++;
            btn.setAttribute('data-index',i);
            btn.addEventListener('click',evt=>{
                evt.preventDefault();
                if(!btn.classList.contains('selected')) {
                    const selected = custom_select.querySelector('button.selected');
                    if(selected!==null) {
                        selected.classList.remove('selected');
                    }
                    btn.classList.add('selected');
                    main_field.value = btn.hasAttribute('data-value') ? btn.getAttribute('data-value') : btn.textContent.trim();
                    custom_select.classList.remove('show');
                    change_field = false;
                    pikulinTrigger(main_field,'change')
                    if(index!==null) {
                        let ii = 0;
                        buttons.forEach(btn=>{
                            ii++;
                            if(btn.classList.contains('selected')) {
                                index.innerHTML = ii;
                                if(ii!==1) {
                                    btn_prev.removeAttribute('disabled');
                                }
                                if(ii!==buttons_count) {
                                    btn_next.removeAttribute('disabled');
                                }
                            }
                        });
                    }
                }
            });
            btn.addEventListener('mouseover',()=>{
                btn.classList.add('focused');
            });
            btn.addEventListener('mouseleave',()=>{
                btn.classList.remove('focused');
            });
        });
        // container.addEventListener('mouseover',show);
        // container.addEventListener('mouseleave',hide);
        fields.forEach(field=>{
            field.addEventListener('focus',function (){
                container.classList.add('focus');
                show();
            });
            field.addEventListener('blur',function (){
                let btn = custom_select.querySelector('button.focused');
                if(btn!==null) {
                    btn.click();
                }
                container.classList.remove('focus');
                hide();
            });
        });
        function show() {
            if(!showed) {
                showed = true;
                custom_select.classList.remove('top');
                custom_select.style.maxHeight = '';
                const rect = custom_select.getBoundingClientRect();
                let h = (window.innerHeight - rect.top),
                    h2 = rect.top - container.getBoundingClientRect().height;
                if(max_height===0) {
                    if(h2>h) {
                        h = h2;
                        custom_select.classList.add('top');
                    }
                } else if(h>max_height) {
                    h = max_height;
                } else if(h2>h) {
                    h = h2>max_height ? max_height : h2;
                    custom_select.classList.add('top');
                }
                custom_select.style.maxHeight = h + 'px';
                custom_select.classList.add('show');
                let tmp = custom_select.querySelector('.selected');
                if(tmp!==null) {
                    custom_select.scrollTo(0, tmp.offsetTop);
                }
            }
        }
        function hide() {
            if(!container.classList.contains('focus')) {
                custom_select.classList.remove('show');
                showed = false;
            }
        }
        main_field.addEventListener('change',fieldOnChange);
        function fieldOnChange() {
            if(change_field) {
                let tmp = custom_select.querySelector('button.selected');
                if(tmp!==null) {
                    tmp.classList.remove('selected');
                }
                let s = false;
                if(main_field.value.length!==0) {
                    tmp = custom_select.querySelector('button[data-value="'+main_field.value+'"]');
                    if(tmp===null) {
                        if(custom_select.querySelectorAll('button[data-value]').length===0) {
                            let n = true;
                            buttons.forEach(btn => {
                                if (btn.textContent.trim() === main_field.value) {
                                    n = false;
                                    btn.classList.add('selected');
                                    s = true;
                                }
                            });
                            if(n) {
                                buttons.forEach(btn => {
                                    if (btn.textContent.trim().indexOf(main_field.value) !== -1) {
                                        s =true;
                                        btn.classList.add('selected');
                                        main_field.value = btn.textContent.trim();
                                        let label = main_field.closest('label');
                                        if(label!==null && label.hasAttribute('data-value')) {
                                            label.setAttribute('data-value',main_field.value);
                                        }
                                    }
                                });
                            }
                        }
                    } else {
                        s = true;
                        tmp.classList.add('selected');
                    }
                }
                if(s && index!==null) {
                    i = 0;
                    buttons.forEach(btn=>{
                        i++;
                        if(btn.classList.contains('selected')) {
                            index.innerHTML = i;
                        }
                    });
                }
            } else {
                change_field = true;
            }
        }
        main_field.addEventListener('keyup',()=>{
            if(change_field) {
                if(main_field.value.length!==0 && main_field.value.indexOf('\n')===-1) {
                    let tmp = custom_select.querySelector('button[data-value="'+main_field.value+'"]');
                    if(tmp===null) {
                        if(custom_select.querySelectorAll('button[data-value]').length===0) {
                            buttons.forEach(btn => {
                                if (btn.textContent.trim() === main_field.value) {
                                    custom_select.scrollTo(0, btn.offsetTop);
                                    pikulinTrigger(main_field,'change');
                                }
                            });
                        } else {
                            let f = false;
                            buttons.forEach(btn => {
                                if (btn.getAttribute('data-value')===main_field.value) {
                                    f = true;
                                    custom_select.scrollTo(0, btn.offsetTop);
                                    pikulinTrigger(main_field,'change');
                                }
                            });
                            if(!f) {
                                buttons.forEach(btn => {
                                    if (btn.getAttribute('data-value').indexOf(main_field.value)!==-1) {
                                        custom_select.scrollTo(0, btn.offsetTop);
                                    }
                                });
                            }
                        }
                    } else {
                        custom_select.scrollTo(0, tmp.offsetTop);
                        pikulinTrigger(main_field,'change');
                    }
                }
            } else {
                change_field = true;
            }
        });
        if(main_field.value.length>0) {
            fieldOnChange();
        }
        if(index!==null) {
            btn_next.addEventListener('click',evt=>{
                evt.preventDefault();
                let current_index = parseInt(index.innerHTML);
                if(current_index<buttons_count) {
                    main_field.value = buttons[current_index].hasAttribute('data-value') ?
                        buttons[current_index].getAttribute('data-value') :
                        buttons[current_index].textContent.trim();
                    current_index++;
                    if(current_index===buttons_count) {
                        btn_next.setAttribute('disabled','disabled');
                    }
                    index.innerHTML = current_index;
                    fieldOnChange();
                    pikulinTrigger(main_field,'change');
                } else {
                    btn_next.setAttribute('disabled','disabled');
                }
                btn_prev.removeAttribute('disabled');
            });
            btn_prev.addEventListener('click',evt=>{
                evt.preventDefault();
                let current_index = parseInt(index.innerHTML);
                if(current_index>1) {
                    current_index--;
                    main_field.value = buttons[current_index - 1].hasAttribute('data-value') ?
                        buttons[current_index - 1].getAttribute('data-value') :
                        buttons[current_index - 1].textContent.trim();
                    if(current_index===1) {
                        btn_prev.setAttribute('disabled','disabled');
                    }
                    index.innerHTML = current_index;
                    fieldOnChange();
                    pikulinTrigger(main_field,'change');
                } else {
                    btn_prev.setAttribute('disabled','disabled');
                }
                btn_next.removeAttribute('disabled');
            });
        }
    });
}
initCustomSelect();
let observerFavorites = new MutationObserver(initCustomSelect);
observerFavorites.observe(document.body, {
    childList: true,
    subtree: true,
});

