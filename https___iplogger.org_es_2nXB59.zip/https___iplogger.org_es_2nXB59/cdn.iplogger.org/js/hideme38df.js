function hideme(json) {	console.log('hideme', json);
    if(json.complete != 1) {    	return;
    }
    $('.block-form-inner[data-stage]').attr('data-stage', 2);
}
