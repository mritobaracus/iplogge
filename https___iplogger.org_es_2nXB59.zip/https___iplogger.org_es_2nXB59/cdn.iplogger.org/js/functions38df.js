Window.prototype['cookieget']=function(name,def){var r=new RegExp(name+'=([^;]*)','i'),c=document.cookie.match(r);if(c&&c.length>0){return c[1]}return def};
Window.prototype['cookieset']=function(name,value){var s=name+'='+value+'; max-age='+(86400*365)+'; path=/; samesite=lax; secure=1';document.cookie=s;};
Window.prototype['refresh']=function(go){if(!go){window.location.reload();return;}window.location.href=go;if(go.replace(/#.*/,'')==window.location.pathname.replace(/#.*/,'')){window.location.reload();}}

if(typeof(console) != 'object') {
	console = {'log': function(w) {},'debug': function(w) {},'error': function(w) {}};
}

/* ajax config */
$.ajaxSetup({
	method: 'POST',
	type: 'POST',
	dataType: "json",
});


/* classlist */
$.fn.classList=function(){return this[0].className.split(/\s+/);};

/* numbers beatifulization 0_o */
function number_format(number, decimals, dec_point, thousands_sep) {
    number = (number + '').replace(/[^0-9+\-Ee.]/g, '');
    var n = !isFinite(+number) ? 0 : +number,
        prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
        sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
        dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
        s = '',
        toFixedFix = function(n, prec) {
            var k = Math.pow(10, prec);
            return '' + (Math.round(n * k) / k)
                .toFixed(prec);
        };
    // Fix for IE parseFloat(0.55).toFixed(0) = 0;
    s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
    if (s[0].length > 3) {
        s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
    }

    if(parseInt(s[1]) == 0) {
    	//return s[0];
    }
    if ((s[1] || '').length < prec) {
        s[1] = s[1] || '';
        s[1] += new Array(prec - s[1].length + 1).join('0');
    }
    return s.join(dec);
}

/* visibility */
var _visibility = {};
if (typeof document.hidden !== "undefined") {
  _visibility['hidden'] = "hidden";
  _visibility['change'] = "visibilitychange";
  _visibility['state'] = "visibilityState";
} else if (typeof document.mozHidden !== "undefined") {
  _visibility['hidden'] = "mozHidden";
  _visibility['change'] = "mozvisibilitychange";
  _visibility['state'] = "mozVisibilityState";
} else if (typeof document.msHidden !== "undefined") {
  _visibility['hidden'] = "msHidden";
  _visibility['change'] = "msvisibilitychange";
  _visibility['state'] = "msVisibilityState";
} else if (typeof document.webkitHidden !== "undefined") {
  _visibility['hidden'] = "webkitHidden";
  _visibility['change'] = "webkitvisibilitychange";
  _visibility['state'] = "webkitVisibilityState";
}

/* clipboard */
if(typeof(copy) != 'function') {
	function copy(text) {
		var $text = $("<input>");
	    $("body").append($text);
		$text.val(text).select();
		var result = document.execCommand("copy");
	    $text.remove();
	    if(!result) {
	    	result = prompt('Copy text:', text);
	    }
	    return result;
	}
}

/* копируем в буфер */
$(document).on('click', '[data-copy]', function(e) {
	e.preventDefault();
	var This = this, text = $(This).attr('data-copy');

	if(text.substr(0, 1) == '#') {		text = $(text).text();
	}

	$(This).addClass('copied');
	setTimeout(function() {
		$(This).removeClass('copied');
	}, 3000);

	copy(text);
});


/* check cacheable pages*/
$('body').attr('onunload', ' ');
var code = $('body').data('integrity');
if(cookieget('integrity') == code) {
	console.error('cacheable page!');
	call('cacheFixer');
}
cookieset('integrity', code);


/* show error */
function showE(errors, $container, $el, $er) {
	if(typeof(errors) != 'object') {		errors = {'error': errors};
	} else if(errors.using) {
    	//limit
    	return;
    }

    if(typeof(errors.errors) == 'object') {    	errors = errors.errors;
    }

    if(typeof($container) != 'object') {
		$container = $('body');
	}

	console.log('showE', errors, $container);

    /*
    input.setCustomValidity("error");
    */
	for(var i in errors) {
		if(!errors[i]) continue;

		$er = $(errors[i]);

		if($container.is('body')) {			$container.prepend($er);
			continue;
		}

        $el = $container.find('[name="'+i+'"]');
		if(!$el.length) {			$container.prepend($er);
			continue;
		}

		if($el.is(':checkbox') || $el.is(':radio')) {			$el = $el.parent();
		}

		$er.hide();
		$el.before($er);

		var css = $el.position();
		css.top -= $er.outerHeight() + 10;
		$er.css(css).show();
	}
}

function hideE() {	$(".error-container").fadeOut(300, function() {		$(this).remove();
	});
}
$(document).on('click', '.error-container > span', function() {
	$(this).parent().fadeOut(300, function() {
		$(this).remove();
	});
});

/* form lite serializer */
function serialize($items) {
	var tmp = [];
	$items.each(function() {
		var name = $(this).attr('name'), value;

		if($(this).is(':radio')) {
			if($(this).prop('checked')) {
				tmp.push({'name': name, 'value': $(this).val()});
			}
		} else if($(this).is(':checkbox')) {
			if($(this).prop('checked')) {
				tmp.push({'name': name, 'value': $(this).val()});
			} else {
				tmp.push({'name': name, 'value': ''});
			}
		} else if(name) {
			tmp.push({'name': name, 'value': this.value});
		}
	});

	return serializeObj(tmp);
}
/* serializeArray() to obj */
function serializeObj(list) {
	var tmp = {};
	for(var i in list) {
		var name = list[i].name, value = list[i].value;
		if(/\[/.test(name)) {
			if(tmp[name]) {
				tmp[name].push(value);
			} else {
				tmp[name] = [value];
			}
		} else {
			tmp[name] = value;
		}
	}

	return tmp;
}

/* URL is umm.. similar an URL */
function isValidURL(destination) {
	if(!destination || typeof(destination) != 'string') {
		return false;
	}
	var url;

	url = destination.split('.');
	if(url.length > 1) {		// w.me
		if(url[0].length > 0 && url[1].length > 1) {
			return true;
		}
		return false;
	}

	url = destination.split(':');
    if(url.length > 1) {    	// intent://cmd
    	if(url[0].length > 2 && url[1].length > 5) {
			return true;
		}
		return false;
	}

	return false;
}


/* auto form */
var __observe;
$('[data-observe="1"]').on('keyup', function(e) {
	if(e.keyCode > 60) {		console.log('data-observe', e.keyCode);
		var $this = $(this);
		clearTimeout(__observe);
		__observe = setTimeout(function() {
			$this.trigger('change');
		}, 5000);
	}
});

window.calee = {	prepare: function($container) {		call('hideE');
		var name = $container.attr('data-name');

        $('[data-contents="'+name+'"]').addClass('loading');
		$container.find('button').removeClass('saved').attr('disabled', true);
        $container.addClass('loading');
	},
	complete: function(json, $container) {		//console.log('complete', json, $container);
    	if(json.page) {
			$container.find('[name="page"]').attr('data-next', json.next||0).val(json.page).trigger('change');
		}
		if(json.close) {
	        dialog.close();
		}
	},
	callback: function(json, $container) {
    	//console.log('callback', json, $container);
	},
	error: function(json, $container) {
    	console.log('error', json, $container);
    	call('showE', json.errors, $container);
	},};

$(document).on('submit', 'form[onsubmit]', formOnSubmit);

function formOnSubmit() {
	console.log('submit');
	var form = this,
		callback = ($(form).attr('data-callback')||calee.callback),
		complete = ($(form).attr('data-complete')||calee.complete),
		prepare = ($(form).attr('data-prepare')||calee.prepare),
		error = ($(form).attr('data-error')||calee.error);

	var url = ($(form).attr('data-action') || window.location.pathname);

	if($(form).data('captcha') == 1) {
		var $captcha = $(form).find('input[name="captcha"]');
		if($captcha.length && $captcha.val() == '') {
			console.log('captcha', );
			var $dialog = $('#modal-captcha');
			$dialog.attr('data-complete', $(form).data('name'));
			var $stager = $dialog.find('.h-captcha');
			if($stager.attr('data-stage') == 2) {
				$stager.attr('data-stage', 3);
			}
			dialog.open('modal-captcha');
			return;
		}
	}

	//reset pages if form submitted manually
	if($(form).data('pagination') == 1) {
		$(form).data('pagination', 0);
	} else {
		$(form).find('input[name="page"]').val(1);
	}

	//var data = $(form).serialize();

	var data = new FormData($(form).get(0));

	ajax(url, data, {
		callback: callback,
		complete: complete,
		prepare: prepare,
		error: error
	}, form);

	return false;
}

document.querySelectorAll('form').forEach(f=>{
	f.submit = () => f.querySelector('[type="submit"]').click();
});

$(document).find('form[data-submit="auto"]').submit();

/* captcha functions */
function captcha_init() {
	$('#modal-captcha .h-captcha').attr('data-stage', 1);
}
function captcha_expired() {
	$('#modal-captcha .h-captcha').attr('data-stage', 3);
	$('input[name="captcha"]').val('');
}

function captcha_complete(key) {
	var name = $('#modal-captcha').attr('data-complete');
	$('input[name="captcha"]').val(key);
	$('#modal-captcha .h-captcha').attr('data-stage', 2);

	console.log('complete', name);

    var $form = $('form[data-name="'+name+'"]');
    $form.submit();

    dialog.close();
    /*
    if(typeof(hcaptcha) == 'object') {
    	hcaptcha.reset();
    }
    */
}

/* function caller */
function call(fn) {    if(typeof fn == 'undefined') {    	return false;
    }
	if(typeof fn == 'string' && typeof window[fn] == 'function') {		fn = window[fn];
	}
	if(typeof fn != 'function') {
		console.error(fn, 'not a function');
		return false;
	}

	//console.log(fn);

    return fn.apply( this, Array.prototype.slice.call(arguments, 1) );
}

/* ajax requests */
function ajax(url, data, handler, container) {	clearTimeout(__observe);	var $container = $(container);

	//console.log('ajax', $container);

	var request = {
	    url: url,
	    data: data,
		success: function(json) {
			if(json.refresh || json.go) {
				return call('refresh', json.go);
			}

			$container.removeClass('loading');
			$container.find('button').attr('disabled', false);

			if(json.call) {
		        call(json.call, json, $container);
			}

			var name = $container.attr('data-name');
			if($('[data-contents="'+name+'"]').length) {				$('[data-contents="'+name+'"]').empty();
			    if(typeof(json.content) == 'object') {
					for(var i in json.content) {
						$('[data-contents="'+name+'"]').append(json.content[i]);
					}
				}
			    $('[data-contents="'+name+'"]').removeClass('loading');
			}

			if(json.errors) {
				return this.error('', '', json.errors, json);
			}

			//console.log('success', $container, handler);

            call(handler.callback, json, $container);
			call(handler.complete, json, $container);
		},
		error: function(e, m, s, json) {			if(typeof(json) != 'object') {				json = {};				if(e.responseJSON) {					json.errors = e.responseJSON.errors;
				}
			}
            if(!json.errors) {
            	json.errors = (s||m);
            }

            //console.log('ajax.error', json, $container, handler.error);

            $container.removeClass('loading');
			$container.find('button').attr('disabled', false);

            call(handler.error, json, $container);
		}
	};

	if(typeof data.getAll == 'function') {
		request['contentType'] = false;
		request['processData'] = false;
		request['dataType'] = 'json';
	}

    call(handler.prepare, $container);

	$.ajax(request);
}

var $lastFormCalled;
function confirmation(data, $container) {
    $lastFormCalled = $container;

	console.log('confirmation', $lastFormCalled);

	$('#modal-rules').find('[data-stage]').attr('data-stage', data.stage);

	dialog.open('modal-rules');
}

function confirmed(data) {	dialog.close();
    console.log('confirmed', $lastFormCalled);
    if($lastFormCalled) {		$lastFormCalled.submit();
	}
}

/* utm builder & destination validator */
var utmtimeoutlistener;
$('.utm-builder .destination').on('input', function(e) {
	var $this = $(this), $utm = $this.parents('.utm-builder'), $stage = $this.parents('[data-stage]');

    $utm.attr('data-utm', 1);
    $stage.attr('data-stage', 0);

	if(e.originalEvent && (e.originalEvent.inputType == 'insertText' || e.originalEvent.inputType == 'deleteContentBackward')) {
		clearTimeout(utmtimeoutlistener);
		utmtimeoutlistener = setTimeout(function() {
        	$this.trigger('input');
		}, 500);
		return;
	}

    var destination = $this.val();
	if(!isValidURL(destination)) {
		return;
	}

    var $form = $this.parents('form');

    $form.addClass('loading');
    $this.attr('readonly', true);

    var $domain = $form.find('select[name="domain"]');
    var $path = $form.find('input[name="manual"]');

	ajax('/check/destination/', {destination: destination, domain: $domain.val(), path: $path.val()}, {
    	callback: function(json, $container) {
			if(json.host) {
				var $img = $utm.find('img'), src;
				if($img.length) {
					src = $img.attr('data-src');
					$img.attr('src', src+json.host);
				}
			}

			if($utm.attr('data-place') == 'create-main-link') {				var $pbutton = $('form[data-name="main"] button:eq(0)');                $form.attr('data-action', $pbutton.attr('data-action'));
			}

			if(json.destination) {
				$utm.attr('data-utm', 2);
				$this.val(json.destination);
				$stage.attr('data-stage', 1);
			}

			if(json.path) {
				$path.val(json.path);
			}
			if(json.domain) {
				$domain.val(json.domain);
			}
		},
    	complete: function(json, $container) {
    		$container.removeClass('loading');
    		$this.removeAttr('readonly');
    	},
    	error: function(json, $container) {    		call('showE', json.errors, $container);
    		$container.removeClass('loading');
    		$this.removeAttr('readonly');
    	}
    }, $form);

});

$('.utm-builder[data-place="create-main-link"] .destination').on('keypress', function(e) {	if(e.keyCode == 13) {    	$(this).parents('form').find('.main-banner-buttons button:eq(0)').click();
	}
});

var $utms = $('#modal-utm').find('input[name^="utm_"]'), $utmp = $('#modal-utm').find('[name="preview"]'), utmu;

function utm($button, $dialog) {	var url = $button.parent().find('input[name="destination"]').val();

	var place = $button.parents('.utm-builder').attr('data-place');

	$('#modal-utm').attr('data-place', place);

	$utmp.val(url);
	$utms.val('');

	utmu = new URL(url);

    utmu['searchParams'].forEach(function(value, key) {
		$('#modal-utm input[name="'+key+'"]').val(value);
	});
}

$utms.on('input change', function(e) {	var name = $(this).attr('name'), value = $(this).val();

    var params = utmu['searchParams'];

	/*
    else if(!params.has(name)) {
    	params.append(name, value);
    }
    */
    if(value == '') {    	params.delete(name);
    } else {    	params.set(name, value);
    }

    $utmp.val(utmu);
});

$('#modal-utm .predefined-utm button').on('click', function() {	var data = $(this).data();

	$utms.val('');
	for(var key in data) {		$('#modal-utm input[name="utm_'+key+'"]').val(data[key]).trigger('change');
	}
});

$('#modal-utm button[data-insert]').on('click', function() {	var url = $utmp.val();

	var place = $('#modal-utm').attr('data-place');

	$('.utm-builder[data-place="'+place+'"] input[name="destination"]').val(url).trigger('input');
	dialog.close();
});

/* global site elements */

//content menu
$('[data-menu]').on('mouseover', '[data-point]', function() {	if(navigator.maxTouchPoints > 0) {
		return;
	}
	$(this).addClass('opened');
});

$('[data-menu]').on('mouseout', '[data-point]', function() {
	if(navigator.maxTouchPoints > 0) {
		return;
	}
	$(this).removeClass('opened');
});

$('[data-menu]').on('click', '[data-dots]', function(e) {
	e.stopPropagation();
	e.preventDefault();

	var $row = $(this).parents('[data-point]');
	if($row.hasClass('opened')) {
		$row.removeClass('opened');
	} else {
		$(this).parents('[data-menu]').find('[data-point]').removeClass('opened');
		$row.addClass('opened');
	}
});

//Adaptive Menu
$('.btn-menu').on('click', function() {
	if($('header').hasClass('active')) {
		$('header').removeClass('active');
    	$('.header-overlay').hide();
	} else {
		$('header').addClass('active');
    	$('.header-overlay').show();
	}
});

//Dropdown Select
$('.inner-content').on('click', function(e) {
	if($(e.target).parents('.block-inner').length) {		return;
	}

	if($(this).hasClass('active')) {
		$(this).removeClass('active');
    	$('.header-overlay').hide();
	} else {
		$(this).addClass('active');
    	$('.header-overlay').show();
	}
});

//overlay
$('.header-overlay').on('click', function() {
	$('.inner-content, header').removeClass('active');
	$('.header-overlay').hide();
});

//Main Banner Scroll
$('.header-link-menu, .main-banner-arrow-down').on("click", "a", function (event) {
    event.preventDefault();
    var id  = $(this).attr('href'),
        top = $(id).offset().top - $('header').outerHeight();
    $('body,html').animate({scrollTop: top}, 2000);
});


//passwords fields
$('.password-view i').on('click', function() {	var $p = $(this).parent();
	if($p.hasClass('active')) {
		$p.removeClass('active');
	    $p.find('input').attr('type', 'password');
	} else {
		$p.addClass('active');
	    $p.find('input').attr('type', 'text');
	}
});

$('[data-stage] [data-index]').on('click', function() {
	var index = $(this).attr('data-index');
	$(this).parents('[data-stage]').attr('data-stage', index);
});

function dialog_fill($button, $dialog) {	var data = $button.data();
	for(var i in data) {
		$dialog.find('input[name="'+i+'"]').val(data[i]);
	}
}


/* modal windows */
var dialog = {	open: function($button) {
        var fn, name = $button, $dialog;

		if(typeof($button) == 'object') {			name = $button.attr('data-dialog');
		}

		var history = ($('body').data('closeHistory')||[]);
        if(history.indexOf(name) > -1) {        	console.error('dialog already opened');
        	return;
        }


		$dialog = $('#'+name);
		if($dialog.length < 1) {
			console.error('unknown dialog');
			return;
		}

		if(typeof($button) == 'object') {
			//prepare dialog with outter function
			if(fn = $button.attr('data-prepare')) {				console.error('prepare '+fn);
		       	call(fn, $button, $dialog);
			}
		}

    	console.log('dialog.open', name, fn);

		var width = $dialog.outerWidth(), pos = 0;
		if(width < (window.innerWidth - 40)) {			pos = (window.innerWidth / 2) - (width / 2);
		}
		$dialog.css('left', pos);

		var height = $dialog.outerHeight();
		$dialog.data('height', height);
		dialog.resize($dialog, height);
		$dialog.data('timer', setInterval(function($dialog) {
			var current = $dialog.outerHeight();
        	if(current != $dialog.data('height')) {
        		dialog.resize($dialog, current);
        	}
		}, 500, $dialog));

    	if(history.length < 1) {
			$('.modal-overlay').addClass('opened');
		}
		history.push(name);
		$('body').data('closeHistory', history);

		$('body').css('overflow', 'hidden');

		$dialog.addClass('opened');


	},
	close: function(history, name, $dialog) {        history = ($('body').data('closeHistory')||[]);
        console.log(history);
        if(!history.length) {
			return;
		}
		name = history.splice(-1);
		if(!name) {			return;
		}
		$dialog = $('#'+name);
		if($dialog.length < 1) {			return;
		}
		$dialog.removeClass('opened');
		if($dialog.data('timer')) {			clearInterval($dialog.data('timer'));
		}
		console.log('dialog.close', name, history);
		if(history.length < 1) {
			$('.modal-overlay').removeClass('opened');
			$('body').css('overflow', '');
		}
	},
	resize: function($dialog, current) {		var top = (window.innerHeight / 2) - (current / 2);
		$dialog.css('top', top+'px');
		$dialog.data('height', current);
	}};

$(document).on('click', '[data-dialog]', function() {	dialog.open($(this));
});

$('.dialog [data-close]').on('click', function() {	dialog.close();
});

$('.modal-overlay').on('click', function() {
    dialog.close();
});


/* pagination */

$('.navy-pages').on('click', '[data-page]', function() {	var current = +$(this).attr('data-current');
	if(current == 1) {		return;
	}

	var page = $(this).attr('data-page');
	var formName = $(this).parents('.navy-pages').attr('data-form');

	var $form = $('form[data-name="'+formName+'"]');
	if(!$form.length) {		return;	}

	$form.find('[name="page"]').val(page);
	$form.data('pagination', 1);
	$form.submit();
});

$('form').on('change', '[name="page"]', function() {
	var page = +$(this).val(), next = +$(this).attr('data-next');
	if(page < 1) {
		page = 1;
		$(this).val(1);
	}

	var $form = $(this).parents('form');
	var name = $form.attr('data-name');
	var $container = $('.navy-pages[data-form="'+name+'"]').find('[data-contain="page"]');

	$container.empty();
	$container.append(createPageItem(1, page));
	if(page > 1) {
	   	var min = 2;
	   	if(page > 3) {
	   		min = page - 2;
	   	}
	   	for(var i = min; i <= page; i++) {
	   		$container.append(createPageItem(i, page));
	   	}
	}
	if(next) {
		$container.append(createPageItem((page + 1), page));
	}
});
$('form [name="page"]').trigger('change');

function createPageItem(index, page) {	var $item = $('<div>');
	$item.html(index);
	$item.attr('data-page', index);
	if(page == index) {		$item.attr('data-current', 1);
	}
	return $item;
}


/* sorting & ordering */
$('label.filter').on('click', function(e) {
    e.stopPropagation();
    e.preventDefault();

    var formName = $(this).attr('data-form');
	var $form = $('form[data-name="'+formName+'"]');
	if(!$form.length) {
		return;
	}

    var $input = $(this).find('input');

    if($input.prop('checked')) {    	$(this).attr('data-order', ($(this).attr('data-order') == 'asc' ? 'desc': 'asc'));
    } else {    	$input.prop('checked', true);
    }
    var sort = $input.val();
    var order = $(this).attr('data-order');

	console.log(order, sort);

    $form.find('[name="page"]').val(1);
	$form.find('[name="sort"]').val(sort);
	$form.find('[name="order"]').val(order);
	$form.submit();

});

$('form').on('change', '[name="sort"], [name="order"]', function() {
	var $form = $(this).parents('form');
	var name = $form.attr('data-name');
	var sort = $form.find('[name="sort"]').val();
	var order = $form.find('[name="order"]').val();

    $('label.filter[data-form="'+name+'"]').find('input[value="'+sort+'"]').prop('checked', true);
    $('label.filter[data-form="'+name+'"]').attr('data-order', order);
});
$('form [name="sort"]').trigger('change');


/* daterange new */
function ymd(days) {
	var now = new Date();
    var offset = (new Date().getTimezoneOffset() * 60 * 1000)
	var utc = new Date(now.getTime() + offset);

	var final = +utc + (_offset * 1000) + (days * (86400 * 1000));

	var date = new Date(final);

	var out = [];
	out.push(date.getFullYear());
	var m = (date.getMonth() + 1);
	out.push((m<10?'0'+m:m));
	var d = date.getDate();
	out.push((d<10?'0'+d:d));

	return out.join('-');
}

var getLocale = (function(system) {	if(system) {		return system;
	}
	if(navigator.languages && navigator.languages.length) {
		return navigator.languages[0];
	}
	return navigator.userLanguage || navigator.language || navigator.browserLanguage || 'en';
})(locale);

function toLocale(name, type) {
	try {
		switch(type) {
			case 'weekday':
				name = name || 1;
				name = new Date(2018,09,name).toLocaleString(getLocale, {weekday: 'long'});
			break;
			case 'hour':
				name = name || 0;
				name = new Date(0,0,0,name).toLocaleTimeString(getLocale, {hour:'2-digit',minute:'2-digit'});
			break;
			default:
				day = new Date(name);
				var format = {month:'short', day:'2-digit'};
				if(day.getYear() != new Date().getYear()) {
					format['year'] = 'numeric';
				}
				name = day.toLocaleDateString(getLocale, format);
			break;
		}
	} catch(e) {		console.error(e);	}

	return name;
}

$('#date-select').on('change', 'input[name="interval"]', function(e) {	console.log();
	var $container = $('#date-select');
    var value = $(this).val();

    $container.find('[data-interval]').removeClass('selected');
	$container.find('[data-interval="'+value+'"]').addClass('selected');

    var $a = $container.find('input[name="range[]"]:eq(0)');
    var $b = $container.find('input[name="range[]"]:eq(1)');
	switch(value) {
		case 'today':
			$a.val(ymd(0));
	   		$b.val(ymd(0));
		break;
		case 'yesterday':
			$a.val(ymd(-1));
	   		$b.val(ymd(-1));
		break;
		case '7days':
			$a.val(ymd(-6));
	   		$b.val(ymd(0));
		break;
		case '30days':
			$a.val(ymd(-29));
	   		$b.val(ymd(0));
		break;
		case 'all':
			$a.val($a.attr('min'));
	   		$b.val($b.attr('max'));
		break;
	}
});

$('[data-name="daterange"] input[name="interval"]').each(function(e) {	var $button = $(this).parents('[data-name="daterange"]');    var $container = $('#date-select');

	var interval = $(this).val();
	var show = $container.find('[data-interval="'+interval+'"]').text();

	drawDate($button, show, interval);
});

$('#date-select').on('change', 'input[name="range[]"]', function(e) {
	var $container = $('#date-select');

    $container.find('[data-interval]').removeClass('selected');
	$container.find('input[name="interval"]').val('');

	var $a = $container.find('input[name="range[]"]:eq(0)');
    var $b = $container.find('input[name="range[]"]:eq(1)');

	var ad = +new Date($a.val()), bd = +new Date($b.val()), now = +new Date(), min = +new Date($a.attr('min'));
	//Hi Emmett!
	if(ad > now) {		$a.val(ymd(0));
	}
	//McFly here you are!
	if(bd > now) {		$b.val(ymd(0));
	}
	if(ad < min) {		$a.val($a.attr('min'));
	}
	if(bd < min) {		$b.val($b.attr('min'));
	}
	if(ad > bd) {
	   	//current input is a
	   	if($a[0] == $(this)[0]) {
			$b.val($a.val());
		} else {
			$a.val($b.val());
		}
	}
});


function dialog_date($button, $dialog) {	var interval = $button.find('input').val();

	$dialog.attr('data-from', $button.data('from'));

	if(interval && interval.indexOf(',') > -1) {		interval = interval.split(',');

		$dialog.find('input[name="range[]"]:eq(0)').val(interval[0]).trigger('change');
        $dialog.find('input[name="range[]"]:eq(1)').val(interval[1]).trigger('change');
	} else {		$dialog.find('input[name="interval"]').val(interval).trigger('change');
	}

}

$('#date-select').on('click', '[data-interval]', function(e) {
    e.preventDefault();
    e.stopPropagation();

    var $container = $('#date-select');
    var interval = $(this).data('interval');

    $container.find('input[name="interval"]').val(interval).trigger('change');
});


$('#date-select').on('click', 'button', function(e) {
    e.preventDefault();
    e.stopPropagation();

    var $container = $('#date-select');
    var $button = $('[data-dialog="date-select"][data-from="'+$container.attr('data-from')+'"]');

    var interval = $container.find('input[name="interval"]').val();
    if(interval) {
		var show = $container.find('[data-interval="'+interval+'"]').text();

		drawDate($button, show, interval);
		return;
	}

	var $a = $container.find('input[name="range[]"]:eq(0)'), a;
	var $b = $container.find('input[name="range[]"]:eq(1)'), b;
	if(!(a = $a.val())) {
		$a.focus();
		return;
	}
	if(!(b = $b.val())) {
		$b.focus();
		return;
	}

    drawDate($button, (toLocale(a)+' - '+toLocale(b)), (a+','+b));
});

function drawDate($button, text, interval) {	var origin = $button.find('input').val();

    $button.find('span').html(text.toLowerCase());
    $button.find('input').val(interval);

	if(origin != interval) {
		$button.find('input').trigger('change');
	}

	dialog.close();
}


$('#cookie-container button, #modal-cookie button').click(function() {
	$('#cookie-container, #modal-cookie').fadeOut(300);
	cookieset('cookies-agreement', new Date());
});
if(!cookieget('cookies-agreement')) {
	$('#cookie-container, #modal-cookie').fadeIn(200);
}


$('#resend-validation').on('click', function(e, $this) {
	$this = $(this);
	$this.attr('disabled', true);

	var complete = function(json) {
		var interval = json.interval || 3;
		$this.attr('data-interval', interval);
		$this.addClass('sended');
		$this.attr('disabled', true);

		var X = setInterval(function() {
			var i = $this.attr('data-interval') - 1;
			$this.attr('data-interval', i);
			if(i < 1) {
				$this.removeClass('sended');
				$this.removeAttr('data-interval');
				$this.removeAttr('disabled');
				clearInterval(X);
			}
		}, 1000);
	};

	ajax('/account/activate/', {}, {complete: complete, error: calee.error}, $this);
});


/* sharebox*/
var ShareWindows = [];
$('#logger-share .share').on('click', function(e) {
	e.preventDefault();

	var share = $(this).attr('data-url'), name = $(this).attr('data-icon');

	share = share.replace(/{[a-z]+}/g, function(t, v) {
		t = t.replace(/({|})/g, '');
		if(v = $('#logger-share').attr('data-'+t)) {			return v;
		}
		return '';
	});

	ShareWindows.push({'name': name, 'window': window.open(share, name)});
});

function share($button, $dialog) {
	var url = $button.attr('data-shortlink');

	new QRious({
		element: document.getElementById('qr'),
		value: url,
		background: 'white',
		foreground: 'black',
		backgroundAlpha: 1,
		foregroundAlpha: 1,
		level: 'L',
		mime: 'image/png',
		size: 250,
		padding: null
	});

	$dialog.attr('data-url', url);
    $dialog.attr('data-title', $button.attr('data-title'));
    $dialog.attr('data-image', $button.attr('data-image'));
}


$('div[data-stage] button[data-back]').on('click', function() {	var $stager = $(this).parents('[data-stage]');

	var step = $(this).attr('data-back'), current = $stager.attr('data-stage'), goto = (current - step);

	if(goto < 1) {    	goto = 1;
	}

	$stager.attr('data-stage', goto);
});


var $fl = $('<div class="dialog-hint-window">'), fl;
$('body').append($fl);
//mouseout
$('body').on('mouseover', '.dialog-hint-wrap', function() {
	console.log('hint');

	var content = $(this).children('span').html();
	$fl.html(content);
	var position = $(this).offset();
	if(position.left + $fl.outerWidth() > $(document).width()) {
		position.left -= $fl.outerWidth();
	} else {
		position.left += $(this).width();
		position.top += $(this).height();
	}
	$fl.css(position);
	$fl.fadeIn(200);
});
$('body').on('mouseout', '.dialog-hint-wrap', function() {
	clearTimeout(fl);
	fl = setTimeout(function() {
		$fl.fadeOut(100);
	}, 100);
});

$fl.on('mouseover', function() {
	clearTimeout(fl);
}).on('mouseout', function(e) {
   	if(!$(e.toElement).hasClass('dialog-hint-window') && !$(e.toElement).parents('.dialog-hint-window').length) {
   		$fl.fadeOut(100);
   	}
});
