$('form[data-name="main"] button').on('click', function() {	var $form = $(this).parents('form');	$form.attr('data-action', $(this).attr('data-action'));
	$form.submit();
});


function animateMainBanner() {	var mainBannerStep = 0, mainBannerInterval = setInterval(function() {

	    $('.main-banner-steps > li').removeClass('current');

		$('.main-banner-steps > li:eq('+mainBannerStep+')').addClass('current');

		var all = $('.main-banner-steps > li').length - 1;
	    if(mainBannerStep >= all) {
	    	mainBannerStep = 0;
	    	clearInterval(mainBannerInterval);
	    	setTimeout(function() {	    		animateMainBanner();
	    	}, 5000);
	    } else {
			mainBannerStep++;
	    }

	}, 2000);
}
animateMainBanner();

