$('.create-list').each(function() {
	var $button = $(this).parents('form').find('button[type="submit"]');

	$button.attr('disabled', true);
	$(this).find('input[name="model"]').on('change', function() {		$button.attr('disabled', false);
	});


});