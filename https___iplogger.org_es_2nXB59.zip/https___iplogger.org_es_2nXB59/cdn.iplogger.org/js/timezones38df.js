function tzloader($button, $dialog) {
	var $tzblock = $('[data-type="tz"]');

	var timezone = $tzblock.find('input[name="timezone"]').val();

    var offset = $dialog.find('select[name="timezone"] option[value="'+timezone+'"]').attr('data-offset');

	$dialog.find('select[name="offset"]').val(offset).trigger('change');
	$dialog.find('select[name="timezone"]').val(timezone);

}
/*
jQuery.extend(jQuery.expr[':'], {
	icontains: function(e, a, o) {		return jQuery(e).text().toUpperCase().indexOf(o[3].toUpperCase()) >= 0
	}
});
*/

var $zdialog = $('#change-timezone');

$zdialog.find('select[name="offset"]').on('change', function() {	var offset = $(this).val();

	var $select = $zdialog.find('select[name="timezone"]');
	$select.find('option').hide();
	var $options = $select.find('option[data-offset="'+offset+'"]');

	$options.show();
    $select.val($options[0].value);
});

$zdialog.find('.dialog-button button').on('click', function() {
	var timezone = $zdialog.find('select[name="timezone"]').val();
    var timezoneTime = $zdialog.find('select[name="timezone"] option:selected').attr('data-time');

    if(!timezone || !timezoneTime) {    	return false;
    }

    var $tzblock = $('[data-type="tz"]');

    $tzblock.find('input[name="timezone"]').val(timezone).trigger('change');
    $tzblock.find('.place [data-content="timezone"]').html(timezone+' ('+timezoneTime+')');

    dialog.close();

});