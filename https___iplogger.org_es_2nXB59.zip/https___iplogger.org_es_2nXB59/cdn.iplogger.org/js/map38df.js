/*
window.gmap = function() {	window.gmarker = new google.maps.Marker({title: "Current location"});
    $('[data-map]').each(function() {
		var $this = $(this);
		var lat = parseFloat($this.data('lat')) || 0, lng = parseFloat($this.data('lng')) || 0, zoom = parseInt($this.data('zoom')) || 8;

		var map = new google.maps.Map($this[0], {
			center: { lat: lat, lng: lng },
		    zoom: zoom
		});

		$this.data('map', map);

		var callback = $this.data('callback');
		if(typeof(window[callback]) == 'function') {
			console.log('call', callback);
			window[callback]($this);
		}
	});

};
*/

// Create the script tag, set the appropriate attributes
var css = document.createElement('link');
css.rel = "stylesheet";
css.href = 'https://cdn.iplogger.org/css/leaflet.css';
css.async = true;
document.head.appendChild(css);

var script = document.createElement('script');
script.src = 'https://cdn.iplogger.org/js/leaflet.js';
script.async = true;
script.onload = function() {
	$('[data-map]').each(function() {
		var $this = $(this);
		var lat = parseFloat($this.data('lat')) || 0, lng = parseFloat($this.data('lng')) || 0, zoom = parseInt($this.data('zoom')) || 8, id;

		if(!(id = $this.attr('id'))) {			id = 'leaflet_'+Math.random().toString().substr(2);			$this.attr('id', id);
		}

		var cords = {lat: lat,lng: lng}
		//console.log('init', cords, id);

        $this.empty();

		var map = L.map(id).setView(cords, zoom);
		$this.data('map', map);
        //console.log('map', map);

		var marker = L.marker();
        $this.data('marker', marker);

        var circle = L.circle([], {
		    color: 'transparent',
		    fillColor: '#004080',
		    fillOpacity: 0.1,
		    radius: 0
		});
		circle.bindPopup('Accuracy');
		$this.data('circle', circle);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
			maxZoom: 18,
			attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
			id: 'mapbox.streets'
		}).addTo(map);
		//console.log('marker',marker);
		var callback = $this.data('callback');
		if(typeof(window[callback]) == 'function') {
			console.log('call', callback);
			window[callback]($this);
		}
	});

}

document.head.appendChild(script);



