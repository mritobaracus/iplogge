let result_interval = 5000, result_counter = 0, rtimer;

function request() {
	if(++result_counter == 12) {
		result_interval = 60000;
	}

	rtimer = setTimeout(function() {
		$('form[data-name="sms-logger"]').submit();
	}, result_interval);
}

if($('form[data-name="sms-logger"]').data('autorefresh') == 1) {
	request();
}




function setupCords($row) {

	$('[data-contents="sms-logger"] [data-map-lat]').removeClass('active');
	$row.addClass('active');

	var lat = parseFloat($row.data('map-lat')),
	lng = parseFloat($row.data('map-lng'));

	if(isNaN(lat)) {
    	$('.for-map').addClass('empty');
	} else {
		$('.for-map').removeClass('empty');

		var data, pos = {lat: lat, lng: lng};

	    if(data = $('.for-map:not(.mobile)').find('[data-map]').data()) {
		    var map = data.map, marker = data.marker;
		    marker.remove();
		    marker.setLatLng(pos);
			marker.addTo(map);
			map.setView(pos, 16, { animation: true });
	    }

	    if(data = $('.for-map.mobile').find('[data-map]').data()) {
		    var map = data.map, marker = data.marker;
		    marker.remove();
		    marker.setLatLng(pos);
			marker.addTo(map);
			map.setView(pos, 16, { animation: true });
	    }
	}
}

$('[data-contents="sms-logger"]').on('click', '.btn-change-map', function(e) {
	e.preventDefault();

	var $row = $(this).parent().parent();

	console.log('btn', $row);
	if($row.hasClass('active')) {
		return;
	}

	setupCords($row);

    if(window.matchMedia("(max-width: 767px)").matches) {
    	var t = $('.for-map.mobile').offset().top;
		window.scroll(0, t - 80);
	}
});

function initMapCords() {
	var $first = $('[data-contents="sms-logger"] > div:first'), data;

	if(data = $('.for-map:not(.mobile)').find('[data-map]').data()) {
    	if(!data.map) {
    		return;
    	}
	}
	if(data = $('.for-map.mobile').find('[data-map]').data()) {
    	if(!data.map) {
    		return;
    	}
	}
	setupCords($first);
}


function sms_result(json, $container) {
	if(json.clicks) {
    	$('.clicks-count').html(json.clicks);
    }
    if(json.clicks > 0) {
    	var $row = $('[data-contents="sms-logger"] > div:first');
    	setupCords($row);
    } else {
    	request();
    }
    if(json['sms-status']) {
    	$('.sms-status').html(json['sms-status']);
    }


}

$('.block.logger-data:not(.demo) button[data-name="refresh"]').on('click', function() {
    clearTimeout(rtimer);
	$('form[data-name="sms-logger"]').submit();
});


var moreInfos = [];
function more_info_set(index) {
	var content = moreInfos[index];


	var $place = $('#more-info [data-contents="info"]');

	$place.empty();

	for(var i in content) {
		$place.append(content[i]);
	}
}

function more_info($button, $dialog) {
	var index = $button.data('index');
	var code = $('form[data-name="sms-logger"] input[name="code"]').val();

	if(moreInfos[index]) {
		more_info_set(index);
	    return;
	}

	$dialog.addClass('loading');

    var data;

    if(data = $dialog.find('[data-map]').data()) {
    	console.log('map', data);

	    var map = data.map, marker = data.marker, circle = data.circle;

	    if(map) {
	    	circle.remove();
	    	marker.remove();
	    }
    }

	ajax('/sms_logger/more/', {'index': index, 'code': code}, {
    	complete: function(json) {
    		moreInfos[index] = json.content;
    		more_info_set(index);

    		if(data) {
				var pos = {
					lat: +json.map.lat,
					lng: +json.map.lng,
				}, zoom = 16;
                if(map) {
				    if(json.map.acc > 200) {
				    	circle.setRadius(json.map.acc);
					    circle.setLatLng(pos);
						circle.addTo(map);
				        zoom = 12;
					}
					marker.setLatLng(pos);
					marker.addTo(map);
					map.setView(pos, zoom, { animation: true });
				}
			}

    		$dialog.removeClass('loading');
    	},
    	error: function(error, json) {
            moreInfos[index] = [];
            more_info_set(index);
    		$dialog.removeClass('loading');
    	}
    });
}


function email_changed(json, $container) {
	if(json.email) {
		$('.data-email').html(json.email);
		dialog.close();
	}
}