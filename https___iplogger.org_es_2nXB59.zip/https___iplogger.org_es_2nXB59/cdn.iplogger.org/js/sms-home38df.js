function init() {
    particlesJS("particles-js", {
        "particles": {
            "number": {
                "value": 20,
                "density": {
                    "enable": true,
                    "value_area": 700
                }
            },
            "color": {
                "value": "#4797dd"
            },
            "shape": {
                "type": "circle",
                "stroke": {
                    "width": 0,
                    "color": "#000000"
                },
                "polygon": {
                    "nb_sides": 5
                },
            },
            "opacity": {
                "value": 1,
                "random": false,
                "anim": {
                    "enable": false,
                    "speed": 0.1,
                    "opacity_min": 0.1,
                    "sync": false
                }
            },
            "size": {
                "value": 10,
                "random": true,
                "anim": {
                    "enable": false,
                    "speed": 5,
                    "size_min": 5,
                    "sync": false
                }
            },
            "line_linked": {
                "enable": true,
                "distance": 150,
                "color": "#4797dd",
                "opacity": 1,
                "width": 2
            },
            "move": {
                "enable": true,
                "speed": 1,
                "direction": "none",
                "random": false,
                "straight": false,
                "out_mode": "out",
                "bounce": false,
                "attract": {
                    "enable": false,
                    "rotateX": 600,
                    "rotateY": 1200
                }
            }
        },
        "interactivity": {
            "detect_on": "canvas",
            "events": {
                "onhover": {
                    "enable": true,
                    "mode": "grab"
                },
                "onclick": {
                    "enable": true,
                    "mode": "push"
                },
                "resize": true
            },
            "modes": {
                "grab": {
                    "distance": 140,
                    "line_linked": {
                        "opacity": 1
                    }
                },
                "bubble": {
                    "distance": 400,
                    "size": 40,
                    "duration": 2,
                    "opacity": 8,
                    "speed": 3
                },
                "repulse": {
                    "distance": 200,
                    "duration": 0.4
                },
                "push": {
                    "particles_nb": 4
                },
                "remove": {
                    "particles_nb": 2
                }
            }
        },
        "retina_detect": true
    });

    function doScrolling(elementY, duration) {
        const startingY = window.pageYOffset,
            diff = elementY - startingY - document.querySelector('#header').getBoundingClientRect().height;
        let start,time;

        window.requestAnimationFrame(function step(timestamp) {
            if (!start) start = timestamp;
            time = timestamp - start;
            window.scrollTo(0, startingY + diff * Math.min(time / duration, 1));
            if (time < duration) {
                window.requestAnimationFrame(step);
            }
        })
    }

    const bg = document.querySelector('.bg');
    if(bg!==null) {
        const p = window.innerWidth/10;
        document.querySelector('.section-sms-banner').addEventListener('mousemove',(e)=>{
            bg.style.marginLeft = '-'+(e.clientX/p)+'%';
        });
    }

    let demo_page = document.querySelector('.demo-page');
    demo_page.style.width = demo_page.closest('.container').getBoundingClientRect().width + 'px';

    window.addEventListener('load',()=>{
        demo_page.style.width = demo_page.closest('.container').getBoundingClientRect().width + 'px';
    });
    window.addEventListener('resize',()=>{
        demo_page.style.width = demo_page.closest('.container').getBoundingClientRect().width + 'px';
    });

    let scroll = null;
    document.querySelectorAll('.btn-hover-data:not(.inited)').forEach(btn=>{
        let datum = document.querySelectorAll(btn.getAttribute('data-toggle'));
        let container = null;
        if(datum.length>0 && datum[0].parentElement!==null) {
            container = datum[0].parentElement;
            while (container.style.overflowY === "" && container.parentElement !== null) {
                container = container.parentElement;
            }
            if (container.style.overflowY === "") {
                container = null;
            }
        }
        btn.addEventListener('mouseover',()=>{
            let r = {top:0},
                rm = {top:999999};
            datum.forEach(data=>{
                data.classList.add('hover');
                let tr = data.getBoundingClientRect();
                if(tr.top>r.top) {
                    r = tr;
                }
                if(tr.top<rm.top) {
                    rm = tr;
                }
            });
            if(container!==null) {
                let tr = container.getBoundingClientRect(),
                    t = r.top - tr.top - tr.height + r.height - container.scrollTop,
                    s = 0;
                if(t>=1) {
                    s = t;
                    let p = s/8;
                    if(scroll===null) {
                        scroll = true;
                        scrollToBottom();
                    } else {
                        scroll = false;
                        let interval = setInterval(()=>{
                            if(scroll===null) {
                                scroll = true;
                                scrollToBottom();
                                clearInterval(interval);
                            }
                        },100);
                    }
                    function scrollToBottom() {
                        if(scroll) {
                            if (container.scrollTop + p >= s) {
                                container.scrollTop = s;
                                scroll = null;
                            } else {
                                container.scrollTop += p;
                                window.requestAnimationFrame(scrollToBottom);
                            }
                        } else {
                            scroll = null;
                        }
                    }
                } else if(rm.top<tr.top) {
                    s = container.scrollTop - tr.top + rm.top;
                    let p = s/8;
                    if(scroll===null) {
                        scroll = true;
                        scrollToTop();
                    } else {
                        scroll = false;
                        let interval = setInterval(()=>{
                            if(scroll===null) {
                                scroll = true;
                                scrollToTop();
                                clearInterval(interval);
                            }
                        },100);
                    }
                    function scrollToTop() {
                        if(scroll) {
                            if(container.scrollTop-p<=s) {
                                container.scrollTop = s;
                                scroll = null;
                            } else {
                                container.scrollTop -= p;
                                window.requestAnimationFrame(scrollToTop);
                            }
                        } else {
                            scroll = null;
                        }
                    }
                }
            }
        });
        btn.addEventListener('mouseout',()=>{
            datum.forEach(data=>{
                data.classList.remove('hover');
            });
        });
    });
}
init();

window.addEventListener('pageChanged',()=>{
    if(window.location.pathname==='/sms_logger/') {
        init();
    }
});